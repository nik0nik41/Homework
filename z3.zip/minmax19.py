import random
n = int(input())
z=0
#l=[0,0,0,0,0,0,0,0,]
l = [random.randint(0, n) for x in range(n)]
print(l)
min=l[0]
for i in range(len(l)):
    if l[i]<min:
        min=l[i]
for i in range(len(l)):
    if l[i]==min:
        z+=1
print(z)