import random
n = int(input())
#l=[0,0,0,0,0,0,0,0,]
l = [random.randint(0, n) for x in range(n)]
max=l[0]
m1pl=mpl=0
print(l)
for i in range(len(l)):
    if l[i]>max:
        max=l[i]
        mpl=i
if mpl==0:
    print(0)
else:
    print(mpl-m1pl-1)

