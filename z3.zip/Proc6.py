K = int(input())
S=0
C=0


def DigitCountSum(K,C,S):
    l=len(str(K))
    while K != 0:
        i = K % 10
        S += i
        K = K // 10
    return l,S




l=DigitCountSum(K,C,S)
print(l)
