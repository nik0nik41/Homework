import random
#K=17
#K=random.randint(0,9999)
K=[random.randint(0,9999) for j in range(10)]
#K=[66,1,2,34,55,12,12,1223,34,99]
p=0
a=[]
c=[]
z=K.copy()
print(z)

def IsPalindrom(K,p,a):
    for n in range(10):
        if K[n] == 0:
            return p
        else:
            while K[n]>0:
                p=p*10+K[n]%10
                K[n]=K[n]//10
            #j= p * 10 + K[n] % 10 K[n] // 10
            a.append(p)
            p=0
    return a
        #return IsPalindrom(K // 10, p * 10 + K % 10)
        #return a.append(IsPalindrom(n // 10, p*10 + n % 10))
m=IsPalindrom(K,p,a)


def check(m,z):
    for n in range(10):
        if m[n] == z[n]:
            c.append('true')

        else:
            c.append('false')
    return c
c=check(m,z)
print(c)