import random
#l=[66,1,2,34,55,12,12,1223,34,99]
n = int(input())
l = [random.randint(0, n) for x in range(n)]
a=[]
print(l)
for i in range(len(l)):
    if l[i]%2==0:
        a.append(l[i])
a.reverse()
print(a,len(a))