import random
x=0
c=0
L=10#int(input())#диапозон чисел в матрице
N =3 #int(input())#кол-во столбиков
M =3 #int(input())#кол-во строк
def matrixgenerator(N,M):
    marx = [[random.randint(0,L) for j in range(N)] for i in range(M)]
    return(marx)
m=matrixgenerator(N,M)
print(m)
for i in range(M):
    for z in range(N):
        if m[i][z]%2==0:
            c+=1
    if c==N:
        x=i+1
        #print(z+1)
    else:
        c=0
if x>0:
    print(x)
else:
    print('четных строчек нет')