import random
L=int(input())#диапозон чисел в матрице
N = int(input())#кол-во столбиков
M = int(input())#кол-во строк
J=int(input())
def matrixgenerator(N,M):
    marx = [[random.randint(0,L) for j in range(N)] for i in range(M)]
    print(marx)
    for i in range(M):
        for z in range(N):
            if z==J-1:
                marx[i][z]*=5
    return marx
m=matrixgenerator(N,M)
print(m)