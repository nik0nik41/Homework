import random
#l=[66,1,2,34,55,12,12,1223,34,99]
z = int(input())
n = [random.randint(0, z) for x in range(z)]
m=n[0]
print(n)
for i in range(1,len(n)):
    m,n[i]=n[i],m
n[0]=0
print(n)

